KiCad V6 libraries for UKMARSBOT

Arduino library elements from: https://github.com/g200kg/kicad-lib-arduino
